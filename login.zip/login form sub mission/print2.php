<?php

$json_string = 'http://localhost/login/print.php';
$jsondata = file_get_contents($json_string);
$obj = json_decode($jsondata,true);
echo "<pre>";
print_r($obj);
?>