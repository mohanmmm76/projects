<?php
require('inc/config.php');
require('inc/functions.php');

if (!isset($_SESSION['UserData'])) {
    exit(header("location:main.html"));
}


require('include/header.php');

header("refresh:1; url=form.html");
?>



