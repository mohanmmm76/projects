<?php

$name=$_POST["name"];$Father=$_POST["Father"];$dob=$_POST["dob"];$degree=$_POST["degree"];$cource=$_POST["cource"];$passedyear= $_POST["passedyear"];$email= $_POST["email"];$phone= $_POST["phone"];


$conn=mysqli_connect("localhost","root","","pls");
echo "u is lucky this time";


if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$conn=mysqli_connect("localhost","root","","pls");
if (mysqli_select_db($conn,'form'))
{
echo "not select db";
}


$sql = "INSERT INTO form (name,Father,dob,degree,cource,passedyear,email,phone)
VALUES ('$name','$Father','$dob','$degree','$cource','$passedyear','$email','$phone')";

if ($conn->query($sql) === TRUE) {
    echo "done";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();

header("refresh:1; url=form.html");
?>